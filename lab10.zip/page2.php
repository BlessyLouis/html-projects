<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 2</title>
    <style>
    body {
    font-family: Arial, sans-serif;
    background-image: url('lab10.jpeg');
    margin: 0;
    padding: 0;
   
}

h1 {
    color: #333;
}

.container {
    max-width: 600px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.container p {
    margin-bottom: 10px;
    color: #333;
}

.container strong {
    font-weight: bold;
}

.container hr {
    margin: 20px 0;
    border: none;
    border-bottom: 1px solid #ddd;
}

/* Style for GET method */
.get-method {
    color: #009688;
}

/* Style for POST method */
.post-method {
    color: #2196F3;
}
</style>
</head>
<body>
<div class="container">
        <h1>Student Information Verification</h1>
  
    <?php
            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                echo "Using GET method:<br>";
                echo "Roll No: " . $_GET['rollNo'] . "<br>";
            echo "Name: " . $_GET['name'] . "<br>";
            echo "Class: " . $_GET['class'] . "<br>";
            echo "Section: " . $_GET['section'] . "<br>";
            echo "Email: " . $_GET['email'] . "<br>";
            echo "Phone Number: " . $_GET['phoneNumber'] . "<br>";
            echo "City: " . $_GET['city'] . "<br>";
                
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                echo "Using POST method:<br>";
                echo "Roll No: " . $_POST['rollNo'] . "<br>";
            echo "Name: " . $_POST['name'] . "<br>";
            echo "Class: " . $_POST['class'] . "<br>";
            echo "Section: " . $_POST['section'] . "<br>";
            echo "Email: " . $_POST['email'] . "<br>";
            echo "Phone Number: " . $_POST['phoneNumber'] . "<br>";
            echo "City: " . $_POST['city'] . "<br>";
            }
        ?>
        </div>

</body>
</html>