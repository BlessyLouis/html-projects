<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect user input
    $name = $_POST["name"];
    $email = $_POST["email"];

    // Set cookies
    setcookie("user_name", $name, time() + (86400 * 30), "/");
    setcookie("user_email", $email, time() + (86400 * 30), "/");
}

// Retrieve stored cookies
$storedName = isset($_COOKIE["user_name"]) ? $_COOKIE["user_name"] : "";
$storedEmail = isset($_COOKIE["user_email"]) ? $_COOKIE["user_email"] : "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie Demo</title>
   <style>
    body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

input[type="submit"] {
    background-color: #007BFF;
    color: #fff;
    cursor: pointer;
}
#showCookiesBtn{
    background-color: #007BFF;
    color: #fff;
    cursor: pointer;
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;

}
.stored-info {
    margin-top: 20px;
    border: 1px solid #ddd;
    padding: 10px;
    border-radius: 4px;
}

a {
    display: block;
    margin-top: 20px;
    text-decoration: none;
    color: #007BFF;
}

a:hover {
    color: #0056b3;
}

   </style>
</head>
<body>
    <div class="container">
        <h1>Cookie Demo Page</h1>

        <form method="post" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <input type="submit" value="Submit">
        </form>

        
            <button id="showCookiesBtn">Show Cookies</button>
  
        <a href="index.html">Back to Home</a>
    </div>

    <script>
        document.getElementById("showCookiesBtn").addEventListener("click", function() {
            alert("Stored Information:\nName: <?php echo $storedName; ?>\nEmail: <?php echo $storedEmail; ?>");
        });
    </script>
</body>
</html>
