<?php
// Start or resume a session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect user input
    $name = $_POST["name"];
    $phone = $_POST["phone"];

    // Set session variables
    $_SESSION["user_name"] = $name;
    $_SESSION["user_phone"] = $phone;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session Demo</title>
<style> body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

input[type="submit"] {
    background-color: #28a745;
    color: #fff;
    cursor: pointer;
}

.stored-info {
    margin-top: 20px;
    border: 1px solid #ddd;
    padding: 10px;
    border-radius: 4px;
}

button {
    background-color: #007BFF;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

a {
    display: block;
    margin-top: 20px;
    text-decoration: none;
    color: #007BFF;
}

a:hover {
    color: #0056b3;
}
</style>
</head>
<body>
    <div class="container">
        <h1>Session Demo Page</h1>

        <form method="post" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>

            <input type="submit" value="Submit">
        </form>

       
            <button id="displaySessionBtn">Display</button>
       
        
        <a href="index.html">Back to Home</a>
    </div>

    <script>
        <?php if (isset($_SESSION["user_name"]) && isset($_SESSION["user_phone"])) : ?>
            document.getElementById("displaySessionBtn").addEventListener("click", function() {
                alert("Stored Information:\nName: <?php echo $_SESSION["user_name"]; ?>\nPhone Number: <?php echo $_SESSION["user_phone"]; ?>");
            });
        <?php endif; ?>
    </script>
</body>
</html>
