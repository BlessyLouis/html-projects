<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Operation Demo</title>
  <style>body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

input[type="submit"] {
    background-color: #28a745;
    color: #fff;
    cursor: pointer;
}

.success-message {
    color: #28a745;
    margin-top: 10px;
}

.error-message {
    color: #dc3545;
    margin-top: 10px;
}

button {
    background-color: #007BFF;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

textarea {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    resize: none;
}

a {
    display: block;
    margin-top: 20px;
    text-decoration: none;
    color: #007BFF;
}

a:hover {
    color: #0056b3;
}
</style>
</head>
<body>
    <div class="container">
        <h1>File Operation Demo Page</h1>

        <form method="post" enctype="multipart/form-data" action="">
            <label for="file">Choose a file:</label>
            <input type="file" id="file" name="file" required>

            <input type="submit" value="Upload">
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Check if the file was uploaded without errors
            if ($_FILES["file"]["error"] == UPLOAD_ERR_OK) {
                $tempName = $_FILES["file"]["tmp_name"];
                $originalName = $_FILES["file"]["name"];

                // Move the uploaded file to a destination directory
                $destination = "uploads/" . $originalName;
                move_uploaded_file($tempName, $destination);

                echo '<div class="success-message">File uploaded successfully!</div>';

                // Save the file path to the session for use in the content view page
                session_start();
                $_SESSION["file_path"] = $destination;
            } else {
                echo '<div class="error-message">Error uploading file.</div>';
            }
        }
        ?>
        
        <a href="index.html">Back to Home</a>
    </div>
</body>
</html>
