<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "Blessy@04";
$database = "lab3";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to create a table if it doesn't exist
function createTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS user_data (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        age INT NOT NULL,
        gender VARCHAR(10) NOT NULL,
        email VARCHAR(255) NOT NULL
    )";

    if ($conn->query($sql) === TRUE) {
        echo "Table created successfully";
    } else {
        echo "Error creating table: " . $conn->error;
    }
}

// Function to insert user data into the table
function insertData($conn, $name, $age, $gender, $email) {
    $sql = "INSERT INTO user_data (name, age, gender, email) VALUES ('$name', $age, '$gender', '$email')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $email = $_POST["email"];

    // Create the table if it doesn't exist
    createTable($conn);

    // Insert user data into the table
    insertData($conn, $name, $age, $gender, $email);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MySQL Connection Demo</title>
    <style>body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input, select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

input[type="submit"], button {
    background-color: #28a745;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button {
    margin-left: 10px;
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 4px
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
}

th {
    background-color: #007BFF;
    color: #fff;
}

#tableContainer {
    margin-top: 20px;
}

a {
    display: block;
    margin-top: 20px;
    text-decoration: none;
    color: #007BFF;
}

a:hover {
    color: #0056b3;
}
</style>
</head>
<body>
    <div class="container">
        <h1>MySQL Connection Demo Page</h1>

        <form method="post" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required>

            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <input type="submit" value="Submit">
            <button type="button" onclick="displayTable()">Display Table</button>
        </form>

        <div id="tableContainer" style="display: none;">
            <h2>Stored User Data</h2>
            <?php
            // Display the stored data in a table
            $result = $conn->query("SELECT * FROM user_data");
            if ($result->num_rows > 0) {
                echo '<table>';
                echo '<tr><th>ID</th><th>Name</th><th>Age</th><th>Gender</th><th>Email</th></tr>';
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row["id"] . '</td>';
                    echo '<td>' . $row["name"] . '</td>';
                    echo '<td>' . $row["age"] . '</td>';
                    echo '<td>' . $row["gender"] . '</td>';
                    echo '<td>' . $row["email"] . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo 'No data available.';
            }
            ?>
        </div>

        <a href="index.html">Back to Home</a>
    </div>

    <script>
        function displayTable() {
            document.getElementById("tableContainer").style.display = "block";
        }
    </script>
</body>
</html>
