<?php
// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$city = $_POST['city'];

// Server-side validation
if (empty($name) || empty($email) || empty($city)) {
  echo "Error: All fields are required.";
  exit;
}

// Check for discount based on city
$discount = ($city == 'Bangalore') ? 20 : 10;

// Display success message and details
echo "<h2>Registration Successful!</h2>";
echo "<p>Name: $name</p>";
echo "<p>Email: $email</p>";
echo "<p>City: $city</p>";
echo "<p>Discount: $discount%</p>";
?>
<style>
/* Add this to your existing CSS file or create a new one */

.success-message {
  background-color: #dff0d8;
  border: 1px solid #d0e9c6;
  border-radius: 3px;
  padding: 15px;
  margin-top: 20px;
}

.success-message h2 {
  color: #3c763d;
}

.success-message p {
  margin: 5px 0;
}

.success-message p:last-child {
  margin-bottom: 0;
}
h2 {
  color: #333; 
  font-size: 24px;
  margin-bottom: 10px; 
}

p {
  color: #666; 
  font-size: 16px; 
  line-height: 1.5; 
  margin-bottom: 15px; 
}


</style>